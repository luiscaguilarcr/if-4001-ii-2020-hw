#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>

int main(int argc, char *argv[]){
    //Variables de declaracion
    int sfd =0, n=0, b;
    char rbuff[1024];
    char sendbuffer[100];
    char fin[5] = "fin\0";
    struct sockaddr_in serv_addr;

    while(1){
        //Inicio cliente
        memset(rbuff, '0', sizeof(rbuff));
        sfd = socket(AF_INET, SOCK_STREAM, 0);

        serv_addr.sin_family = AF_INET;
        serv_addr.sin_port = htons(5000);
        serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    
        //Creando la conexion
        b=connect(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
        if (b==-1) {
            perror("Conectado");
            return 1;
        }
   
        char dir[100];
        //Obtener el directorio
        printf("Digite el directorio: ");
        if (fgets(dir, sizeof(dir), stdin) == NULL) { 

            perror("fgets error");
            return 2;
        }
        
        dir[strlen(dir) -1] = '\0'; 
        printf("Usted entro: %s\n", dir);

        //Se termina si fin es presionado
        if (strcmp(dir, fin) == 0){
            printf("Coneccion terminada.\n" );
            return 0;
        }

        //Abre el png
        FILE *fp = fopen(dir, "rb");
        if(fp == NULL){
            perror("Archivo");
            return 2;
        }

        //Envia el png al servidor
        while( (b = fread(sendbuffer, 1, sizeof(sendbuffer), fp))>0 ){
            send(sfd, sendbuffer, b, 0);
        }

        close(sfd);
        fclose(fp);
    }   
    return 0;
}